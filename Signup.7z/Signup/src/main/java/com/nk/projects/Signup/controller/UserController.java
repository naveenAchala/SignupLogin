package com.nk.projects.Signup.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.nk.projects.Signup.DTO.UserDTO;
import com.nk.projects.Signup.entity.User;
import com.nk.projects.Signup.service.UserService;

@RestController
@CrossOrigin
@RequestMapping("api/v1/user")
public class UserController {
	
	@Autowired
	private UserService userService;
	
	@GetMapping("/")
	public String insertUser() {
		
		User user = new User();
		user.setUser_name("Deva");
		user.setPassword("Devansh");
		
		User us = userService.saveUser(user);
		
		return "User Name:"+us.getUser_name()+" User Id is: "+us.getId();
		
	}
	
	@PostMapping(path = "/save")
	public String saveUser(@RequestBody UserDTO userDTO) {
		String id = userService.addUser(userDTO);
	}
	
}
