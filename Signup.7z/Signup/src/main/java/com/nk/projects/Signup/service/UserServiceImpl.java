package com.nk.projects.Signup.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nk.projects.Signup.DTO.UserDTO;
import com.nk.projects.Signup.entity.User;
import com.nk.projects.Signup.repository.UserRepository;

@Service
public class UserServiceImpl implements UserService {
	
	@Autowired
	private UserRepository userRepostory;

	@Override
	public User saveUser(User user) {
		return userRepostory.save(user);
	}

	@Override
	public User updateUser(User user) {
		return userRepostory.save(user);
	}

	@Override
	public void deleteUser(User user) {
		userRepostory.delete(user);
	}

	@Override
	public User findById(long id) {
		return userRepostory.findById(id).get();
	}

	@Override
	public List<User> findAll() {
		return userRepostory.findAll();
	}

	}

}
