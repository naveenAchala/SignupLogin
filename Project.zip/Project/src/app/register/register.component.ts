import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators, AbstractControl } from '@angular/forms';
import { AuthService } from '../auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
})
export class RegisterComponent {
  registerForm: FormGroup;

  constructor(private fb: FormBuilder, private authService: AuthService, private router: Router) {
    this.registerForm = this.fb.group(
      {
        employeeName: ['', [Validators.required, Validators.minLength(3)]],
        email: ['', [Validators.required, Validators.email]],
        password: ['', [Validators.required, Validators.minLength(6)]],
        confirmPassword: ['', Validators.required],
      },
      { 
        validators: this.passwordsMatchValidator,
      }
    );
  }

  // For template access
  get f(): { [key: string]: AbstractControl } {
    return this.registerForm.controls;
  }

  // Helper to apply validation classes dynamically
  isInvalid(controlName: string): boolean {
    const control = this.f[controlName];
    return control.invalid && (control.dirty || control.touched);
  }

  // Custom validator
  passwordsMatchValidator(form: AbstractControl): { [key: string]: boolean } | null {
    const pass = form.get('password')?.value;
    const confirm = form.get('confirmPassword')?.value;
    return pass === confirm ? null : { passwordMismatch: true };
  }

  register() {
  if (this.registerForm.invalid) return;

  const { employeeName, email, password } = this.registerForm.value;

  const request = { employeename: employeeName, email, password };

  this.authService.register(request).subscribe({
    next: (res) => {
      if (res.message === 'Email already exists') {
        alert('An account with this email already exists.');
        this.router.navigate(['/login']);
      } else if (res.message === 'Registration successful') {
        alert('Registration successful!');
        this.router.navigate(['/login']);
      } else {
        alert('Unexpected response: ' + res.message);
      }
    },
    error: (err) => {
      console.error('Registration error:', err);
      alert('Registration failed!');
    },
  });
}

}

