import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { tap } from 'rxjs/operators'; // ✅ Add this

@Injectable({ providedIn: 'root' })
export class AuthService {
  private user: any = null;

  constructor(private http: HttpClient, private router: Router) {}

  login(data: any) {
    return this.http.post<any>('http://localhost:8080/api/v1/employee/login', data).pipe(
      tap((res) => {
        if (res.status) {
          this.user = res.user;
          localStorage.setItem('isLoggedIn', 'true');
          localStorage.setItem('user', JSON.stringify(this.user));
        }
      })
    );
  }

  register(data: any) {
    return this.http.post<any>('http://localhost:8080/api/v1/employee/save', data);
  }

  getUser() {
    return this.user || JSON.parse(localStorage.getItem('user') || '{}');
  }

  isAuthenticated(): boolean {
    return localStorage.getItem('isLoggedIn') === 'true';
  }

  logout() {
    this.user = null;
    localStorage.clear();
    this.router.navigate(['/login']);
  }
}
