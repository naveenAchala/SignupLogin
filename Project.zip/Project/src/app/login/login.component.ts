import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators, AbstractControl } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html'
})
export class LoginComponent {
  loginForm: FormGroup;

  constructor(
    private fb: FormBuilder,
    private authService: AuthService,
    private router: Router
  ) {
    this.loginForm = this.fb.group({
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(6)]]
    });
  }

  get f(): { [key: string]: AbstractControl } {
    return this.loginForm.controls;
  }

  isInvalid(controlName: string): boolean {
    const control = this.f[controlName];
    return control.invalid && (control.touched || control.dirty);
  }

  login() {
    this.loginForm.markAllAsTouched(); // reinforce validation display
    if (this.loginForm.invalid) return;

    const { email, password } = this.loginForm.value;

    this.authService.login({ email, password }).subscribe({
      next: (res: any) => {
        if (res.status) {
          alert('Login Successful!');
          this.router.navigate(['/home']);
        } else {
          alert('Login Failed: ' + res.message);
        }
      },
      error: () => {
        alert('An error occurred while trying to log in.');
      }
    });
  }
}
